package com.cinestream.iptv.ui.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cinestream.iptv.data.local.ProfileStore
import com.cinestream.iptv.ui.screens.content.ContentListScreen
import com.cinestream.iptv.ui.screens.home.HomeScreen
import com.cinestream.iptv.ui.screens.login.LoginScreen
import com.cinestream.iptv.ui.screens.player.PlayerScreen

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val CONTENT_LIST = "content_list/{typeName}"
    const val PLAYER = "player/{title}/{url}"

    fun contentList(typeName: String) = "content_list/$typeName"
    fun player(title: String, url: String): String {
        val encTitle = Uri.encode(title)
        val encUrl = Uri.encode(url)
        return "player/$encTitle/$encUrl"
    }
}

@Composable
fun CineNavGraph(profileStore: ProfileStore, startDestination: String) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Routes.LOGIN) {
            LoginScreen(
                profileStore = profileStore,
                onLoggedIn = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                profileStore = profileStore,
                onOpenCategoryType = { typeName ->
                    navController.navigate(Routes.contentList(typeName))
                },
                onPlay = { title, url ->
                    navController.navigate(Routes.player(title, url))
                },
                onLogout = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = Routes.CONTENT_LIST,
            arguments = listOf(navArgument("typeName") { type = NavType.StringType })
        ) { backStackEntry ->
            val typeName = backStackEntry.arguments?.getString("typeName") ?: "LIVE"
            ContentListScreen(
                profileStore = profileStore,
                typeName = typeName,
                onPlay = { title, url -> navController.navigate(Routes.player(title, url)) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.PLAYER,
            arguments = listOf(
                navArgument("title") { type = NavType.StringType },
                navArgument("url") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val title = Uri.decode(backStackEntry.arguments?.getString("title") ?: "")
            val url = Uri.decode(backStackEntry.arguments?.getString("url") ?: "")
            PlayerScreen(title = title, streamUrl = url, onBack = { navController.popBackStack() })
        }
    }
}
