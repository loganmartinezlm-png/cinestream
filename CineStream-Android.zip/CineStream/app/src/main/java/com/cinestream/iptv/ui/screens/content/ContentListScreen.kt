package com.cinestream.iptv.ui.screens.content

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinestream.iptv.data.ContentRepository
import com.cinestream.iptv.data.ContentRow
import com.cinestream.iptv.data.local.ProfileStore
import com.cinestream.iptv.data.model.ContentItem
import com.cinestream.iptv.data.model.ContentType
import com.cinestream.iptv.ui.screens.home.components.ContentRowView
import com.cinestream.iptv.ui.theme.CineBlack
import com.cinestream.iptv.ui.theme.CineRed
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun ContentListScreen(
    profileStore: ProfileStore,
    typeName: String,
    onPlay: (String, String) -> Unit,
    onBack: () -> Unit
) {
    val type = remember { ContentType.valueOf(typeName) }
    var rows by remember { mutableStateOf<List<ContentRow>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Pour les séries : liste d'épisodes affichée quand une série est sélectionnée
    var selectedSeriesTitle by remember { mutableStateOf<String?>(null) }
    var episodes by remember { mutableStateOf<List<ContentItem>>(emptyList()) }
    var repository by remember { mutableStateOf<ContentRepository?>(null) }

    val scope = rememberCoroutineScope()

    LaunchedEffect(typeName) {
        val profile = profileStore.profileFlow.first() ?: return@LaunchedEffect
        val repo = ContentRepository(profile)
        repository = repo
        try {
            rows = repo.getRows(type)
        } catch (e: Exception) {
            errorMessage = e.message ?: "Erreur de chargement"
        } finally {
            isLoading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(CineBlack)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                if (selectedSeriesTitle != null) selectedSeriesTitle = null else onBack()
            }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Retour", tint = Color.White)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = selectedSeriesTitle ?: titleFor(type),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        when {
            isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CineRed)
            }

            errorMessage != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(errorMessage ?: "", color = Color.White)
            }

            selectedSeriesTitle != null -> {
                LazyColumn(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    items(episodes, key = { it.id }) { ep ->
                        EpisodeRow(ep) { onPlay(ep.title, ep.streamUrl) }
                    }
                }
            }

            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(rows, key = { it.category.id }) { row ->
                        ContentRowView(row = row) { item ->
                            if (type == ContentType.SERIES) {
                                scope.launch {
                                    selectedSeriesTitle = item.title
                                    episodes = repository?.getSeriesEpisodes(item.id) ?: emptyList()
                                }
                            } else {
                                onPlay(item.title, item.streamUrl)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(item: ContentItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onClick) {
            Text(item.title, color = Color.White, fontSize = 14.sp)
        }
    }
}

private fun titleFor(type: ContentType): String = when (type) {
    ContentType.LIVE -> "Chaînes en direct"
    ContentType.MOVIE -> "Films"
    ContentType.SERIES -> "Séries"
}
