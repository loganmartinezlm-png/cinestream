package com.cinestream.iptv.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cinestream.iptv.data.local.ProfileStore
import com.cinestream.iptv.data.model.ContentItem
import com.cinestream.iptv.data.model.ContentType
import com.cinestream.iptv.ui.screens.home.components.ContentRowView
import com.cinestream.iptv.ui.screens.home.components.FeaturedBanner
import com.cinestream.iptv.ui.theme.CineBlack
import com.cinestream.iptv.ui.theme.CineRed
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    profileStore: ProfileStore,
    onOpenCategoryType: (String) -> Unit,
    onPlay: (String, String) -> Unit,
    onLogout: () -> Unit
) {
    val viewModel: HomeViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val profile = profileStore.profileFlow.first()
        if (profile != null) viewModel.loadIfNeeded(profile)
    }

    Box(modifier = Modifier.fillMaxSize().background(CineBlack)) {
        when {
            uiState.isLoading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = CineRed)
                }
            }

            uiState.errorMessage != null -> {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(uiState.errorMessage ?: "Erreur", color = Color(0xFFFFFFFF))
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { scope.launch { onLogout() } },
                            colors = ButtonDefaults.buttonColors(containerColor = CineRed)
                        ) { Text("Se reconnecter") }
                    }
                }
            }

            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    item {
                        TopBar(onLogout = {
                            scope.launch {
                                profileStore.clearProfile()
                                onLogout()
                            }
                        })
                    }

                    val featured = uiState.liveRows.firstOrNull()?.items?.firstOrNull()
                        ?: uiState.movieRows.firstOrNull()?.items?.firstOrNull()

                    if (featured != null) {
                        item {
                            FeaturedBanner(item = featured, onPlay = { onPlay(featured.title, featured.streamUrl) })
                        }
                    }

                    if (uiState.supportsVod) {
                        item {
                            SectionShortcut(
                                onMovies = { onOpenCategoryType(ContentType.MOVIE.name) },
                                onSeries = { onOpenCategoryType(ContentType.SERIES.name) },
                                onLive = { onOpenCategoryType(ContentType.LIVE.name) }
                            )
                        }
                    }

                    item { Spacer(Modifier.height(8.dp)) }

                    items(uiState.liveRows.take(8), key = { "live_" + it.category.id }) { row ->
                        ContentRowView(row = row) { item -> onPlay(item.title, item.streamUrl) }
                    }

                    items(uiState.movieRows.take(4), key = { "movie_" + it.category.id }) { row ->
                        ContentRowView(row = row) { item -> onPlay(item.title, item.streamUrl) }
                    }

                    items(uiState.seriesRows.take(4), key = { "series_" + it.category.id }) { row ->
                        ContentRowView(row = row) { item ->
                            // pour une série, on ouvre directement le premier épisode via l'écran liste (gestion simplifiée)
                            onOpenCategoryType(ContentType.SERIES.name)
                        }
                    }

                    item { Spacer(Modifier.height(32.dp)) }
                }
            }
        }
    }
}

@Composable
private fun TopBar(onLogout: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("CineStream", color = CineRed, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = onLogout) {
            Icon(Icons.Filled.Logout, contentDescription = "Déconnexion", tint = androidx.compose.ui.graphics.Color.White)
        }
    }
}

@Composable
private fun SectionShortcut(onLive: () -> Unit, onMovies: () -> Unit, onSeries: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ShortcutChip("Live TV", onLive, Modifier.weight(1f))
        ShortcutChip("Films", onMovies, Modifier.weight(1f))
        ShortcutChip("Séries", onSeries, Modifier.weight(1f))
    }
}

@Composable
private fun ShortcutChip(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(onClick = onClick, modifier = modifier) {
        Text(label, fontSize = 13.sp)
    }
}

// alias léger pour lisibilité (évite d'importer androidx.compose.ui.graphics.Color partout ci-dessus)
private typealias Color = androidx.compose.ui.graphics.Color
