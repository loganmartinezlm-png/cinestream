package com.cinestream.iptv.data.m3u

import com.cinestream.iptv.data.model.Category
import com.cinestream.iptv.data.model.ContentItem
import com.cinestream.iptv.data.model.ContentType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object M3UParser {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    data class ParseResult(
        val items: List<ContentItem>,
        val categories: List<Category>
    )

    /** Télécharge puis parse une playlist M3U/M3U8 distante */
    suspend fun fetchAndParse(m3uUrl: String): ParseResult {
        val request = Request.Builder().url(m3uUrl).build()
        val body = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Erreur HTTP ${response.code}")
            response.body?.string() ?: throw Exception("Playlist vide")
        }
        return parse(body)
    }

    fun parse(content: String): ParseResult {
        val items = mutableListOf<ContentItem>()
        val categoryNames = linkedSetOf<String>()

        val lines = content.lines()
        var pendingTitle: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String? = null
        var index = 0

        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                pendingTitle = line.substringAfterLast(",", missingDelimiterValue = "Sans titre").trim()
                pendingLogo = Regex("tvg-logo=\"([^\"]*)\"").find(line)?.groupValues?.get(1)
                pendingGroup = Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.get(1) ?: "Divers"
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                // c'est l'URL du flux, associée aux métadonnées lues juste avant
                val group = pendingGroup ?: "Divers"
                categoryNames.add(group)
                items.add(
                    ContentItem(
                        id = "m3u_${index++}",
                        title = pendingTitle ?: "Sans titre",
                        posterUrl = pendingLogo,
                        categoryId = group,
                        streamUrl = line,
                        type = guessType(line)
                    )
                )
                pendingTitle = null
                pendingLogo = null
                pendingGroup = null
            }
        }

        val categories = categoryNames.map { Category(id = it, name = it, type = ContentType.LIVE) }
        return ParseResult(items, categories)
    }

    /** Heuristique simple : une playlist M3U mélange souvent tout, on la traite comme "live" par défaut,
     *  sauf extension typique d'un fichier film (mp4/mkv) qu'on classe en VOD. */
    private fun guessType(url: String): ContentType {
        val lower = url.lowercase()
        return if (lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".avi")) {
            ContentType.MOVIE
        } else {
            ContentType.LIVE
        }
    }
}
