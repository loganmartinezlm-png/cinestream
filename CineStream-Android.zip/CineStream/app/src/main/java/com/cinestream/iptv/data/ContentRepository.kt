package com.cinestream.iptv.data

import com.cinestream.iptv.data.m3u.M3UParser
import com.cinestream.iptv.data.model.*
import com.cinestream.iptv.data.remote.XtreamRepository

/** Une rangée de contenu façon Netflix : un titre de catégorie + ses items */
data class ContentRow(val category: Category, val items: List<ContentItem>)

class ContentRepository(private val profile: PlaylistProfile) {

    private val xtream: XtreamRepository? =
        if (profile.type == PlaylistType.XTREAM) XtreamRepository(profile) else null

    // Cache simple en mémoire pour la playlist M3U (téléchargée une seule fois)
    private var m3uCache: M3UParser.ParseResult? = null

    private suspend fun getM3U(): M3UParser.ParseResult {
        return m3uCache ?: M3UParser.fetchAndParse(profile.m3uUrl).also { m3uCache = it }
    }

    suspend fun getRows(type: ContentType): List<ContentRow> {
        return if (xtream != null) {
            val categories = xtream.getCategories(type)
            categories.mapNotNull { cat ->
                val items = when (type) {
                    ContentType.LIVE -> xtream.getLiveStreams(cat.id)
                    ContentType.MOVIE -> xtream.getVodStreams(cat.id)
                    ContentType.SERIES -> xtream.getSeriesList(cat.id)
                }
                if (items.isEmpty()) null else ContentRow(cat, items)
            }
        } else {
            // M3U : tout est mélangé, on ne montre les rangées que pour le type LIVE
            if (type != ContentType.LIVE) return emptyList()
            val result = getM3U()
            result.categories.mapNotNull { cat ->
                val items = result.items.filter { it.categoryId == cat.id }
                if (items.isEmpty()) null else ContentRow(cat, items)
            }
        }
    }

    suspend fun getSeriesEpisodes(seriesId: String): List<ContentItem> {
        return xtream?.getSeriesEpisodes(seriesId) ?: emptyList()
    }

    /** true si les séries/films sont disponibles (uniquement avec Xtream Codes) */
    fun supportsVodAndSeries(): Boolean = xtream != null
}
