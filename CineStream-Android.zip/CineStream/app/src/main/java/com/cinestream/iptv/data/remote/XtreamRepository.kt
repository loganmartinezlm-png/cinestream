package com.cinestream.iptv.data.remote

import com.cinestream.iptv.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Toute la logique Xtream Codes : construction des URLs player_api.php
 * et des URLs de flux (live / film / épisode).
 */
class XtreamRepository(private val profile: PlaylistProfile) {

    private val baseHost = profile.host.trimEnd('/')

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        .build()

    private val api: XtreamApiService = Retrofit.Builder()
        .baseUrl("$baseHost/") // requis par Retrofit même si on utilise des URLs absolues via @Url
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(XtreamApiService::class.java)

    private fun apiUrl(action: String, extra: String = ""): String {
        return "$baseHost/player_api.php?username=${profile.username}&password=${profile.password}&action=$action$extra"
    }

    // ---------- Catégories ----------

    suspend fun getCategories(type: ContentType): List<Category> {
        val dtos = when (type) {
            ContentType.LIVE -> api.getLiveCategories(apiUrl("get_live_categories"))
            ContentType.MOVIE -> api.getVodCategories(apiUrl("get_vod_categories"))
            ContentType.SERIES -> api.getSeriesCategories(apiUrl("get_series_categories"))
        }
        return dtos.map { Category(it.categoryId, it.categoryName, type) }
    }

    // ---------- Contenus ----------

    suspend fun getLiveStreams(categoryId: String? = null): List<ContentItem> {
        val extra = categoryId?.let { "&category_id=$it" } ?: ""
        return api.getLiveStreams(apiUrl("get_live_streams", extra)).map { dto ->
            ContentItem(
                id = dto.streamId.toString(),
                title = dto.name,
                posterUrl = dto.streamIcon,
                categoryId = dto.categoryId,
                streamUrl = "$baseHost/live/${profile.username}/${profile.password}/${dto.streamId}.m3u8",
                type = ContentType.LIVE
            )
        }
    }

    suspend fun getVodStreams(categoryId: String? = null): List<ContentItem> {
        val extra = categoryId?.let { "&category_id=$it" } ?: ""
        return api.getVodStreams(apiUrl("get_vod_streams", extra)).map { dto ->
            val ext = dto.containerExtension ?: "mp4"
            ContentItem(
                id = dto.streamId.toString(),
                title = dto.name,
                posterUrl = dto.streamIcon,
                categoryId = dto.categoryId,
                streamUrl = "$baseHost/movie/${profile.username}/${profile.password}/${dto.streamId}.$ext",
                type = ContentType.MOVIE
            )
        }
    }

    suspend fun getSeriesList(categoryId: String? = null): List<ContentItem> {
        val extra = categoryId?.let { "&category_id=$it" } ?: ""
        return api.getSeries(apiUrl("get_series", extra)).map { dto ->
            ContentItem(
                id = dto.seriesId.toString(),
                title = dto.name,
                posterUrl = dto.cover,
                categoryId = dto.categoryId,
                streamUrl = "", // une série n'a pas de flux direct, il faut d'abord choisir un épisode
                type = ContentType.SERIES
            )
        }
    }

    /** Retourne la liste des épisodes (avec leur URL de lecture directe) pour une série donnée */
    suspend fun getSeriesEpisodes(seriesId: String): List<ContentItem> {
        val info = api.getSeriesInfo(apiUrl("get_series_info", "&series_id=$seriesId"))
        val episodes = info.episodes?.values?.flatten() ?: emptyList()
        return episodes.map { ep ->
            val ext = ep.containerExtension ?: "mp4"
            ContentItem(
                id = ep.id,
                title = "S${ep.season ?: "?"} • ${ep.title}",
                posterUrl = null,
                categoryId = null,
                streamUrl = "$baseHost/series/${profile.username}/${profile.password}/${ep.id}.$ext",
                type = ContentType.SERIES
            )
        }
    }
}
