package com.cinestream.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.cinestream.iptv.data.local.ProfileStore
import com.cinestream.iptv.ui.navigation.CineNavGraph
import com.cinestream.iptv.ui.navigation.Routes
import com.cinestream.iptv.ui.theme.CineBlack
import com.cinestream.iptv.ui.theme.CineStreamTheme
import kotlinx.coroutines.flow.first

class MainActivity : ComponentActivity() {

    private lateinit var profileStore: ProfileStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        profileStore = ProfileStore(applicationContext)

        setContent {
            CineStreamTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(profileStore)
                }
            }
        }
    }
}

@Composable
private fun AppRoot(profileStore: ProfileStore) {
    var startDestination by remember { mutableStateOf<String?>(null) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        val existing = profileStore.profileFlow.first()
        startDestination = if (existing != null && (existing.host.isNotBlank() || existing.m3uUrl.isNotBlank())) {
            Routes.HOME
        } else {
            Routes.LOGIN
        }
    }

    val dest = startDestination
    if (dest == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(CineBlack),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        CineNavGraph(profileStore = profileStore, startDestination = dest)
    }
}
