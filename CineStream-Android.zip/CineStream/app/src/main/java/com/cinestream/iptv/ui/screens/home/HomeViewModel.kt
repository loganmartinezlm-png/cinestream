package com.cinestream.iptv.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinestream.iptv.data.ContentRepository
import com.cinestream.iptv.data.ContentRow
import com.cinestream.iptv.data.model.ContentType
import com.cinestream.iptv.data.model.PlaylistProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val liveRows: List<ContentRow> = emptyList(),
    val movieRows: List<ContentRow> = emptyList(),
    val seriesRows: List<ContentRow> = emptyList(),
    val supportsVod: Boolean = false
)

class HomeViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private var loadedForProfile: String? = null

    fun loadIfNeeded(profile: PlaylistProfile) {
        val key = profile.host + profile.m3uUrl + profile.username
        if (loadedForProfile == key) return
        loadedForProfile = key

        viewModelScope.launch {
            _uiState.value = HomeUiState(isLoading = true)
            try {
                val repo = ContentRepository(profile)
                val live = repo.getRows(ContentType.LIVE)
                val movies = if (repo.supportsVodAndSeries()) repo.getRows(ContentType.MOVIE) else emptyList()
                val series = if (repo.supportsVodAndSeries()) repo.getRows(ContentType.SERIES) else emptyList()

                _uiState.value = HomeUiState(
                    isLoading = false,
                    liveRows = live,
                    movieRows = movies,
                    seriesRows = series,
                    supportsVod = repo.supportsVodAndSeries()
                )
            } catch (e: Exception) {
                _uiState.value = HomeUiState(
                    isLoading = false,
                    errorMessage = e.message ?: "Impossible de charger la playlist. Vérifie tes identifiants ou ta connexion."
                )
            }
        }
    }
}
