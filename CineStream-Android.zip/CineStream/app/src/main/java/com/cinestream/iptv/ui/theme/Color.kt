package com.cinestream.iptv.ui.theme

import androidx.compose.ui.graphics.Color

val CineBlack = Color(0xFF0A0A0A)
val CineSurface = Color(0xFF141414)
val CineSurfaceLight = Color(0xFF232323)
val CineRed = Color(0xFFE50914)
val CineRedDark = Color(0xFFB20710)
val CineTextPrimary = Color(0xFFFFFFFF)
val CineTextSecondary = Color(0xFFB3B3B3)
