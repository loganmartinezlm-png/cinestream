package com.cinestream.iptv.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cinestream.iptv.data.model.PlaylistProfile
import com.cinestream.iptv.data.model.PlaylistType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cinestream_profile")

class ProfileStore(private val context: Context) {

    private object Keys {
        val TYPE = stringPreferencesKey("type")
        val NAME = stringPreferencesKey("name")
        val HOST = stringPreferencesKey("host")
        val USERNAME = stringPreferencesKey("username")
        val PASSWORD = stringPreferencesKey("password")
        val M3U_URL = stringPreferencesKey("m3u_url")
    }

    val profileFlow: Flow<PlaylistProfile?> = context.dataStore.data.map { prefs ->
        val typeStr = prefs[Keys.TYPE] ?: return@map null
        PlaylistProfile(
            type = PlaylistType.valueOf(typeStr),
            name = prefs[Keys.NAME] ?: "Mon compte",
            host = prefs[Keys.HOST] ?: "",
            username = prefs[Keys.USERNAME] ?: "",
            password = prefs[Keys.PASSWORD] ?: "",
            m3uUrl = prefs[Keys.M3U_URL] ?: ""
        )
    }

    suspend fun saveProfile(profile: PlaylistProfile) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TYPE] = profile.type.name
            prefs[Keys.NAME] = profile.name
            prefs[Keys.HOST] = profile.host
            prefs[Keys.USERNAME] = profile.username
            prefs[Keys.PASSWORD] = profile.password
            prefs[Keys.M3U_URL] = profile.m3uUrl
        }
    }

    suspend fun clearProfile() {
        context.dataStore.edit { it.clear() }
    }
}
