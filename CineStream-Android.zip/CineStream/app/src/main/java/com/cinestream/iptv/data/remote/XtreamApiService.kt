package com.cinestream.iptv.data.remote

import com.cinestream.iptv.data.model.*
import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Url

/**
 * L'API Xtream Codes fonctionne via un unique endpoint player_api.php
 * avec un paramètre "action" qui change de comportement.
 * On garde donc une URL dynamique (@Url) construite par XtreamRepository.
 */
interface XtreamApiService {

    @GET
    suspend fun getLiveCategories(@Url url: String): List<XtreamCategoryDto>

    @GET
    suspend fun getVodCategories(@Url url: String): List<XtreamCategoryDto>

    @GET
    suspend fun getSeriesCategories(@Url url: String): List<XtreamCategoryDto>

    @GET
    suspend fun getLiveStreams(@Url url: String): List<XtreamLiveStreamDto>

    @GET
    suspend fun getVodStreams(@Url url: String): List<XtreamVodStreamDto>

    @GET
    suspend fun getSeries(@Url url: String): List<XtreamSeriesDto>

    @GET
    suspend fun getSeriesInfo(@Url url: String): XtreamSeriesInfoResponse
}
