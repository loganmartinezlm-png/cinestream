package com.cinestream.iptv.ui.screens.home.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.cinestream.iptv.data.ContentRow
import com.cinestream.iptv.data.model.ContentItem

@Composable
fun ContentRowView(row: ContentRow, onItemClick: (ContentItem) -> Unit) {
    Column(modifier = Modifier.padding(bottom = 18.dp)) {
        Text(
            text = row.category.name,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(row.items, key = { it.id }) { item ->
                PosterCard(item = item, onClick = { onItemClick(item) })
            }
        }
    }
}
