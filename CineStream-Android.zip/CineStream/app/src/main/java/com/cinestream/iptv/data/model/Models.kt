package com.cinestream.iptv.data.model

import com.google.gson.annotations.SerializedName

/** Type de source de la playlist choisie par l'utilisateur */
enum class PlaylistType { XTREAM, M3U }

/** Profil de connexion sauvegardé localement (un seul profil actif à la fois ici) */
data class PlaylistProfile(
    val type: PlaylistType,
    val name: String = "Mon compte",
    // Pour Xtream Codes
    val host: String = "",       // ex: http://exemple.com:8080
    val username: String = "",
    val password: String = "",
    // Pour M3U simple
    val m3uUrl: String = ""
)

/** Élément générique affiché dans l'UI (chaîne live, film, série) */
data class ContentItem(
    val id: String,
    val title: String,
    val posterUrl: String?,
    val categoryId: String?,
    val streamUrl: String,
    val type: ContentType,
    val extra: String? = null // ex: rating, année...
)

enum class ContentType { LIVE, MOVIE, SERIES }

data class Category(
    val id: String,
    val name: String,
    val type: ContentType
)

// ---------- Réponses brutes de l'API Xtream Codes (player_api.php) ----------

data class XtreamCategoryDto(
    @SerializedName("category_id") val categoryId: String,
    @SerializedName("category_name") val categoryName: String
)

data class XtreamLiveStreamDto(
    @SerializedName("stream_id") val streamId: Int,
    @SerializedName("name") val name: String,
    @SerializedName("stream_icon") val streamIcon: String?,
    @SerializedName("category_id") val categoryId: String?
)

data class XtreamVodStreamDto(
    @SerializedName("stream_id") val streamId: Int,
    @SerializedName("name") val name: String,
    @SerializedName("stream_icon") val streamIcon: String?,
    @SerializedName("category_id") val categoryId: String?,
    @SerializedName("container_extension") val containerExtension: String?
)

data class XtreamSeriesDto(
    @SerializedName("series_id") val seriesId: Int,
    @SerializedName("name") val name: String,
    @SerializedName("cover") val cover: String?,
    @SerializedName("category_id") val categoryId: String?
)

data class XtreamSeriesInfoResponse(
    @SerializedName("episodes") val episodes: Map<String, List<XtreamEpisodeDto>>?
)

data class XtreamEpisodeDto(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("container_extension") val containerExtension: String?,
    @SerializedName("season") val season: Int?
)
