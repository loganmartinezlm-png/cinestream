package com.cinestream.iptv.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CineDarkColorScheme = darkColorScheme(
    primary = CineRed,
    onPrimary = CineTextPrimary,
    secondary = CineRedDark,
    background = CineBlack,
    onBackground = CineTextPrimary,
    surface = CineSurface,
    onSurface = CineTextPrimary,
    surfaceVariant = CineSurfaceLight,
    onSurfaceVariant = CineTextSecondary
)

@Composable
fun CineStreamTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CineDarkColorScheme,
        typography = CineTypography,
        content = content
    )
}
