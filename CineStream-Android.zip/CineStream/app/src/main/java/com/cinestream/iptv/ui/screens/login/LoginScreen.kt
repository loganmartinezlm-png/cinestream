package com.cinestream.iptv.ui.screens.login

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinestream.iptv.data.local.ProfileStore
import com.cinestream.iptv.data.model.PlaylistProfile
import com.cinestream.iptv.data.model.PlaylistType
import com.cinestream.iptv.ui.theme.CineBlack
import com.cinestream.iptv.ui.theme.CineRed
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(profileStore: ProfileStore, onLoggedIn: () -> Unit) {
    var mode by remember { mutableStateOf(PlaylistType.XTREAM) }

    var host by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var m3uUrl by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CineBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "CineStream", color = CineRed, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Connecte ta playlist IPTV",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(32.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(4.dp)
        ) {
            ModeButton(label = "Xtream Codes", selected = mode == PlaylistType.XTREAM, modifier = Modifier.weight(1f)) {
                mode = PlaylistType.XTREAM
            }
            ModeButton(label = "Lien M3U", selected = mode == PlaylistType.M3U, modifier = Modifier.weight(1f)) {
                mode = PlaylistType.M3U
            }
        }

        Spacer(Modifier.height(24.dp))

        if (mode == PlaylistType.XTREAM) {
            CineTextField(value = host, onValueChange = { host = it }, label = "Adresse du serveur (http://exemple.com:8080)")
            Spacer(Modifier.height(12.dp))
            CineTextField(value = username, onValueChange = { username = it }, label = "Nom d'utilisateur")
            Spacer(Modifier.height(12.dp))
            CineTextField(value = password, onValueChange = { password = it }, label = "Mot de passe", isPassword = true)
        } else {
            CineTextField(value = m3uUrl, onValueChange = { m3uUrl = it }, label = "URL de la playlist M3U / M3U8")
        }

        errorMessage?.let {
            Spacer(Modifier.height(12.dp))
            Text(text = it, color = CineRed, fontSize = 13.sp)
        }

        Spacer(Modifier.height(28.dp))

        Button(
            onClick = {
                errorMessage = null
                val valid = if (mode == PlaylistType.XTREAM) {
                    host.isNotBlank() && username.isNotBlank() && password.isNotBlank()
                } else {
                    m3uUrl.isNotBlank()
                }
                if (!valid) {
                    errorMessage = "Merci de remplir tous les champs."
                    return@Button
                }
                isLoading = true
                scope.launch {
                    val profile = PlaylistProfile(
                        type = mode,
                        host = host.trim(),
                        username = username.trim(),
                        password = password.trim(),
                        m3uUrl = m3uUrl.trim()
                    )
                    profileStore.saveProfile(profile)
                    isLoading = false
                    onLoggedIn()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CineRed),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
            } else {
                Text("Se connecter", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (selected) CineRed else Color.Transparent
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CineTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isPassword: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CineRed,
            cursorColor = CineRed
        )
    )
}
