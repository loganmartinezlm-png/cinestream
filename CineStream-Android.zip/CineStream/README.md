# CineStream — Lecteur IPTV (Android)

Application Android native (Kotlin + Jetpack Compose + Media3/ExoPlayer) permettant de lire
une playlist IPTV via **lien M3U** ou via l'**API Xtream Codes** (host / username / password),
avec une interface inspirée de Netflix (bannière en vedette + rangées horizontales par catégorie).

## Fonctionnalités

- Connexion par **Xtream Codes** (récupère automatiquement les catégories Live / Films / Séries
  via `player_api.php`) ou par **lien M3U/M3U8** brut (parsing des tags `#EXTINF`, `tvg-logo`,
  `group-title`).
- Accueil façon Netflix : bannière en vedette + rangées horizontales scrollables par catégorie.
- Lecture des flux **live (TS/HLS)**, **films (VOD)** et **séries** (liste des épisodes) via
  Media3 ExoPlayer, avec support HLS natif.
- Profil sauvegardé localement (DataStore) : pas besoin de se reconnecter à chaque lancement.
- Thème sombre, palette noir/rouge inspirée de Netflix.

## Structure du projet

```
CineStream/
  app/src/main/java/com/cinestream/iptv/
    data/
      model/         -> modèles de données (ContentItem, Category, PlaylistProfile...)
      remote/         -> client Xtream Codes (Retrofit)
      m3u/            -> parseur de playlists M3U
      local/          -> sauvegarde du profil (DataStore)
      ContentRepository.kt -> couche unifiée Xtream / M3U utilisée par l'UI
    ui/
      screens/login/   -> écran de connexion (choix Xtream / M3U)
      screens/home/    -> écran d'accueil façon Netflix
      screens/content/ -> vue "tout voir" par type (Live / Films / Séries)
      screens/player/  -> lecteur vidéo (Media3 ExoPlayer)
      navigation/      -> graphe de navigation Compose
      theme/           -> couleurs et typographie
    MainActivity.kt
```

## Compiler l'APK

1. Ouvre le dossier `CineStream/` dans **Android Studio** (version récente, ex: Iguana ou plus
   récent) — au premier lancement, Android Studio régénère automatiquement le wrapper Gradle et
   synchronise le projet.
2. Laisse le Gradle Sync se terminer (il télécharge les dépendances : Compose, Media3, Retrofit,
   Coil).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. L'APK généré se trouve dans `app/build/outputs/apk/debug/app-debug.apk`, installable
   directement sur un téléphone/TV Android (activer "Sources inconnues" si besoin).

> Si tu préfères la ligne de commande et que Gradle est installé sur ta machine :
> ```
> cd CineStream
> gradle wrapper          # génère gradlew (une seule fois)
> ./gradlew assembleDebug
> ```

## Notes techniques

- Le trafic **HTTP non chiffré** est autorisé (`network_security_config.xml`), car la grande
  majorité des serveurs Xtream Codes/IPTV tournent en `http://` et non `https://`.
- Les URLs de flux Xtream sont construites selon le format standard :
  - Live : `http://host:port/live/user/pass/ID.m3u8`
  - Film : `http://host:port/movie/user/pass/ID.ext`
  - Épisode : `http://host:port/series/user/pass/ID.ext`
- minSdk 24 (Android 7.0+), targetSdk 34.

## Pistes d'amélioration possibles

- Recherche texte dans les catégories/chaînes.
- Favoris / reprise de lecture.
- Guide TV (EPG) via l'action Xtream `get_short_epg`.
- Support multi-profils (plusieurs comptes IPTV enregistrés).
- Cast Chromecast.
